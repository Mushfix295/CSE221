#!/usr/bin/env python
# coding: utf-8

# In[2]:


input_file = open("input6.txt","r")
output_file = open("output6.txt","w")

num = int(input_file.readline()) - 1
arr = list(map(int,input_file.readline().split(" ")))
queries = int(input_file.readline())

def quickAlgo(arr,n,query):
    if n == -1:
        return
    else:
        count = partition(arr,n)
        if count == query:
            output_file.write(f"{arr[n]}\n")
        else:
            quickAlgo(arr,n-1,query)

def partition(arr,n):
    pivot = arr[n]
    count = 0
    for num in range(len(arr)):
        if arr[num]<=pivot:
            count+=1
    return count

for i in range(queries):
    query = int(input_file.readline())
    quickAlgo(arr,num,query)  

input_file.close()
output_file.close()


# In[ ]:




