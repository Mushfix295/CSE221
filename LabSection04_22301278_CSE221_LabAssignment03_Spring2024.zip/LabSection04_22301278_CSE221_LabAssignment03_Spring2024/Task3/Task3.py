#!/usr/bin/env python
# coding: utf-8

# In[1]:


def merge(left, right, count):
    i, j = 0, 0
    sorted_list = []
    while i < len(left) and j < len(right):
        if left[i] <= right[j]:
            sorted_list.append(left[i])
            i += 1
        else:
            sorted_list.append(right[j])
            count += (len(left) - i)
            j += 1
    if i == len(left):
        sorted_list += right[j:]
    else:
        sorted_list += left[i:]
    return sorted_list, count

def mergesort(arr, count):
    if len(arr) == 1:
        return arr, count
    mid = len(arr) // 2
    left = arr[:mid]
    right = arr[mid:]
    left_sorted, left_count = mergesort(left, count)
    right_sorted, right_count = mergesort(right, count)
    count = left_count + right_count
    return merge(left_sorted, right_sorted, count)

with open("input3.txt", "r") as inp:
    n = int(inp.readline())
    nums = list(map(int, inp.readline().split(" ")))
sorted_nums, total_count = mergesort(nums, 0)

with open("output3.txt", "w") as out:
    out.write(f"{total_count}")


# In[ ]:




