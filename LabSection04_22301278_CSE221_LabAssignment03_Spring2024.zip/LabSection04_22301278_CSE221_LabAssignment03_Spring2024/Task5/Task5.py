#!/usr/bin/env python
# coding: utf-8

# In[2]:


with open("input5.txt", "r") as input_file, open("output5.txt", "w") as output_file:
    high = int(input_file.readline()) - 1
    arr = list(map(int, input_file.readline().split()))

    def quickSort(arr, low, high):
        if low < high:
            pivot_idx = partition(arr, low, high)
            quickSort(arr, low, pivot_idx - 1)
            quickSort(arr, pivot_idx + 1, high)
        return arr

    def partition(arr, low, high):
        pivot_idx = low - 1
        pivot = arr[high]
        for num in range(low, high):
            if arr[num] <= pivot:
                pivot_idx += 1
                arr[pivot_idx], arr[num] = arr[num], arr[pivot_idx]
        arr[pivot_idx + 1], arr[high] = arr[high], arr[pivot_idx + 1]
        return pivot_idx + 1

    sorted_arr = quickSort(arr, 0, high)
    output_str = ' '.join(map(str, sorted_arr))
    output_file.write(output_str)


# In[ ]:




