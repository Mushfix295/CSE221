#!/usr/bin/env python
# coding: utf-8

# In[1]:


with open("input4.txt", "r") as input_file, open("output4.txt", "w") as output_file:
    num_elements = int(input_file.readline())
    elements = list(map(int, input_file.readline().split()))

    def merge_and_calculate(first_half, second_half):
        global max_values
        max_first_half = max(first_half)
        max_second_half = max(abs(num) for num in second_half)
        calculation = max_first_half + max_second_half**2
        max_values.append(calculation)
        return first_half + second_half

    def merge_sort(data):
        if len(data) <= 1:
            return data
        else:
            middle = len(data) // 2
            sorted_first_half = merge_sort(data[:middle])
            sorted_second_half = merge_sort(data[middle:])
            merged_data = merge_and_calculate(sorted_first_half, sorted_second_half)
            return merged_data

    max_values = []
    merge_sort(elements)
    max_calculation = max(max_values)
    output_file.write(f"{max_calculation}")


# In[ ]:




