#!/usr/bin/env python
# coding: utf-8

# In[1]:


def merge(a, b):
    i = 0
    j = 0
    sorted_arr = []
    while i<len(a) and j<len(b) :
        if a[i]<=b[j]:
            sorted_arr.append(a[i])
            i+=1
        else:
            sorted_arr.append(b[j])
            j+=1
    if i == len(a):
        sorted_arr=sorted_arr+b[j:]
    else:
        sorted_arr=sorted_arr+a[i:]
    return sorted_arr  


def mergeSort(arr):
    if len(arr) <= 1:
        return arr
    else:
        mid = len(arr)//2
        a1 = mergeSort(arr[:mid])   
        a2 = mergeSort(arr[mid:])  
        return merge(a1, a2)          
    
with open("input1.txt","r") as input_file:
    num = int(input_file.readline())
    arr = list(map(int, input_file.readline().split(" ")))

new_list = mergeSort(arr)

with open("output1.txt","w") as output_file:
    for item in new_list:
        output_file.write(f"{item} ")


# In[ ]:




