#!/usr/bin/env python
# coding: utf-8

# In[1]:


def find_max(arr):
    if len(arr) == 1:
        return arr[0]
    else:
        mid = len(arr) // 2
        left_max = find_max(arr[:mid])
        right_max = find_max(arr[mid:])
        return get_highest(left_max, right_max)

def get_highest(x, y):
    if x >= y:
        return x
    else:
        return y

with open("input2.txt", "r") as file_reader:
    num = int(file_reader.readline())
    numbers = list(map(int, file_reader.readline().split(" ")))

max_value = find_max(numbers)

with open("output2.txt", "w") as file_writer:
    file_writer.write(f"{max_value} \nAnd the time complexity is O(logN)")


# In[ ]:




