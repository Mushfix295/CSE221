#!/usr/bin/env python
# coding: utf-8

# In[1]:


input_file=open("input2.txt","r")
output_file=open("output2.txt","w")


num = input_file.readline()
line = input_file.readline()
arr = list(map(int,line.split(" ")))


def bubbleSort(arr):
    for i in range(len(arr)-1):
        flag = True
        for j in range(len(arr)-i-1):
            if arr[j] > arr[j+1]:
                arr[j], arr[j+1] = arr[j+1], arr[j]
                flag=False

        if flag == True:
            break
    for item in arr:
        output_file.write(f"{item} ") 
    
bubbleSort(arr)
input_file.close()
output_file.close()


# In[ ]:




