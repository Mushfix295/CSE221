#!/usr/bin/env python
# coding: utf-8

# In[3]:


def selection_sort(ids, marks):
    n = len(marks)
    for i in range(n):
        max_idx = i
        for j in range(i+1, n):
            if marks[j] > marks[max_idx] or (marks[j] == marks[max_idx] and ids[j] < ids[max_idx]):
                max_idx = j
        marks[i], marks[max_idx] = marks[max_idx], marks[i]
        ids[i], ids[max_idx] = ids[max_idx], ids[i]
        
with open('input3.txt', 'r') as file:
    n = int(file.readline().strip())
    student_ids = list(map(int, file.readline().split()))
    marks = list(map(int, file.readline().split()))
    
selection_sort(student_ids, marks)
with open('output3.txt', 'w') as file:
    for i in range(n):
        file.write(f'ID: {student_ids[i]} Mark: {marks[i]}\n')


# In[ ]:





# In[ ]:




