#!/usr/bin/env python
# coding: utf-8

# In[1]:


input_file = open('input1.txt','r')
output_file = open('output1.txt','w')

from heapq import heappop, heappush


node,edge = tuple(map(int,input_file.readline().split(" ")))

graph = {}

for node in range(node+1):
    graph[node]=[]

for item in range(edge):
    u,v,w = tuple(map(int,input_file.readline().split(" ")))
    graph[u].append((v,w))

# print(graph)

def dijkstra(graph,source):
    visited = [0]*(node+1)
    distance = [float("inf")]*(node+1)
    distance[source] = 0
    #Creating a priority queue so that the node with the least distance gets pop each time
    priority_queue = []
    heappush(priority_queue,(0,source))
    #Used min heap to sort the nodes according to their distance
    while priority_queue:
        dist, index = heappop(priority_queue)
        visited[index] = 1
        for v in graph[index]:
            if visited[v[0]]==0:
                new_dist = distance[index]+v[1]
                #when the new distance is smaller than the previously assigned distance, new distance is assigned
                if new_dist<distance[v[0]]:
                    distance[v[0]]=new_dist
                    heappush(priority_queue,(new_dist,v[0]))

    for idx in range(1,len(distance)):
        if distance[idx]==float("inf"):
            output_file.write(f"{-1} ")
        else:
            output_file.write(f"{distance[idx]} ")
    
source = int(input_file.readline())

dijkstra(graph,source)



input_file.close()
output_file.close()


# In[ ]:




