#!/usr/bin/env python
# coding: utf-8

# In[3]:


import heapq

def find_safest_path(n, edges):
    graph = {}
    for i in range(1, n+1):
        graph[i] = []

    distance = {}
    for i in range(1, n+1):
        distance[i] = float('inf')
    distance[1] = 0
    
    for u, v, w in edges:
        graph[u].append((v, w))
        graph[v].append((u, w))

    heap = [(0, 1)]
    
    while heap:
        danger, node = heapq.heappop(heap)
        if node == n:
            return danger
        for neighbor, weight in graph[node]:
            max_danger = max(danger, weight)
            if max_danger < distance[neighbor]:
                distance[neighbor] = max_danger
                heapq.heappush(heap, (max_danger, neighbor))
    
    return "Impossible"

with open('input3.txt', 'r') as input_file:
    n, m = map(int, input_file.readline().split())
    edges = []
    for i in range(m):
        edge_data = input_file.readline().split()
        u, v, w = int(edge_data[0]), int(edge_data[1]), int(edge_data[2])
        edges.append((u, v, w))

safest_path = find_safest_path(n, edges)

with open('output3.txt', 'w') as output_file:
    output_file.write(str(safest_path) + '\n')


# In[ ]:




